﻿- inline images from file system
- image resizing
- dialog load doesn't prompt anymore
- can edit hyperlinks when selected
- can set background color
- can hyperlink images
