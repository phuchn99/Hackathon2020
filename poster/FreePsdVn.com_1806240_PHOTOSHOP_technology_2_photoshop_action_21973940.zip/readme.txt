------------------------------------------------------
VIDEO TUTORIAL
------------------------------------------------------

https://youtu.be/9sDuaKbHXU0

------------------------------------------------------
PLEASE RATE THE FILE IF YOU LIKE IT :)
------------------------------------------------------

Thank you for the purchase. It means a lot to me. Please support my work by giving a rating if you like the product. It gives my work more exposure and I’ll be motivated to make more great products for you. Thank you!

----------------------------

This action has been tested and working on Photoshop (English version only) CS4+

If you are not using the English version of Photoshop, you can always change it to English
and then back again to your native language using this method below.

https://www.youtube.com/watch?v=GJAiu5W2gLE

If you are a Creative Cloud subscriber, you can also change your language using the method below:

https://helpx.adobe.com/creative-cloud/help/change-install-language.html

------------------------------------------------------
PLEASE CHECK
------------------------------------------------------

1. Your photo is in RGB color mode

2. Your photo is in 8bit color mode

3. You are running the English version of Photoshop.

4. If you are experiencing errors, try resetting your Photoshop preferences. To do this,
hold down Alt, Ctrl, and Shift keys (Mac: Command, Option, Shift) while starting up Photoshop. 
A dialog box will appear asking if you wish to delete the preferences/settings file. Alternatively,
visit the help page mentioned on the item preview page. 

5. Avoid using small resolution images. For the best results, use Photos between 
2000px - 4000px high/wide.

6. Make sure that the option "Add copy to Copied Layers and Groups" is turned on.
-On the "LAYERS" panel, click on the menu icon, go to "Panel Options..." and check that the "Add copy to Copied Layers and Groups" is turned on.


------------------------------------------------------
HOW TO INSTALL THE ACTION
------------------------------------------------------

1. Open Photoshop :)
2. Make sure your Actions Panel is open. If not, go to Window > Actions.
3. In the actions palette on the top right corner click on the lines icon. Next, click on Load Actions.
4. Select the action you wish to install and then click Open.
5. Your action must now appear in the actions palette.

------------------------------------------------------
HOW TO INSTALL THE PATTERNS
------------------------------------------------------

1. Open Photoshop :)
2. Open menu Edit -> Presets -> Preset manager
3. Choose Patterns from the dropdown menu
4. Click "Load" from the right side of the window
5. Open the .pat file

------------------------------------------------------
HOW TO USE THE ACTION
------------------------------------------------------

1. Open your image and be sure it is on "Background" locked layer

2. Create new layer and rename it "area" (lowercase letters)

3. Paint the area where you want the particle pattern appear. Make the area with a brush or pen tool. It should be rasterized layer. You can use soft or sharp edged brush.

4. Click play when you have the action selected in the actions panel. The action will ask you save the file, save it in order to make the effect work. 

5. When the action is done, you can adjust the scale and position of the graphics


------------------------------------------------------
IF YOU HAVE QUESTIONS
------------------------------------------------------

Contact me through the email form at https://graphicriver.net/user/ninebrains



